const fetch = require('node-fetch');
const config = require('../config');
const { UpstreamError } = require('./errors');

const BASE_URL = 'https://api.coingecko.com/api/v3';

function headers() {
  // The free "Demo" plan (what most people sign up for) authenticates
  // with x-cg-demo-api-key against the same base URL used below. The
  // paid Pro plan uses a different header (x-cg-pro-api-key) AND a
  // different base URL (pro-api.coingecko.com) - mixing the two doesn't
  // work, so this must match whichever plan COINGECKO_API_KEY is from.
  return config.coingeckoApiKey ? { 'x-cg-demo-api-key': config.coingeckoApiKey } : undefined;
}

// CoinGecko's search/quote endpoints key by "id" (e.g. "bitcoin"), not by
// ticker ("BTC"). This is a small, common-coin lookup table so the rest of
// the API can accept a familiar ticker. Extend as needed, or swap for a
// cached call to /coins/list if you want full coverage.
const TICKER_TO_ID = {
  BTC: 'bitcoin', ETH: 'ethereum', SOL: 'solana', XRP: 'ripple', ADA: 'cardano',
  DOGE: 'dogecoin', DOT: 'polkadot', AVAX: 'avalanche-2', MATIC: 'matic-network',
  LINK: 'chainlink', LTC: 'litecoin', UNI: 'uniswap', ATOM: 'cosmos', XLM: 'stellar',
};

function resolveId(ticker) {
  const upper = ticker.toUpperCase();
  return TICKER_TO_ID[upper] || ticker.toLowerCase();
}

async function getQuote(ticker) {
  const id = resolveId(ticker);
  const res = await fetch(
    `${BASE_URL}/coins/${id}?localization=false&tickers=false&community_data=false&developer_data=false`,
    { headers: headers() }
  );
  if (!res.ok) throw new UpstreamError(`CoinGecko quote request failed for ${ticker}`, res.status);
  const data = await res.json();
  if (!data.market_data) throw new UpstreamError(`No market data for "${ticker}".`, 404);

  return {
    ticker: ticker.toUpperCase(),
    name: data.name,
    logoUrl: data.image?.small || null,
    price: data.market_data.current_price.usd,
    previousClose: data.market_data.current_price.usd - data.market_data.price_change_24h,
    currency: 'USD',
    sector: 'Crypto',
    country: 'Global',
    dividendYield: 0,
  };
}

const DAYS_BY_RANGE = { '1D': 1, '1W': 7, '1M': 30, '3M': 90, '1Y': 365, ALL: 1825 };

async function getHistory(ticker, range) {
  const id = resolveId(ticker);
  const days = DAYS_BY_RANGE[range] || 30;
  const res = await fetch(`${BASE_URL}/coins/${id}/market_chart?vs_currency=usd&days=${days}`, { headers: headers() });
  if (!res.ok) throw new UpstreamError(`CoinGecko history request failed for ${ticker}`, res.status);
  const data = await res.json();
  if (!Array.isArray(data.prices)) return [];
  return data.prices.map(([t, v]) => ({ date: new Date(t).toISOString().slice(0, 10), value: v }));
}

async function search(query) {
  const res = await fetch(`${BASE_URL}/search?query=${encodeURIComponent(query)}`, { headers: headers() });
  if (!res.ok) throw new UpstreamError('CoinGecko search request failed', res.status);
  const data = await res.json();
  return (data.coins || []).slice(0, 10).map((c) => ({
    ticker: c.symbol.toUpperCase(),
    name: c.name,
    assetClass: 'crypto',
  }));
}

module.exports = { getQuote, getHistory, search };
